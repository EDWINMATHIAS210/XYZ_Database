-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema xyz
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema xyz
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `xyz` DEFAULT CHARACTER SET utf8 ;
USE `xyz` ;

-- -----------------------------------------------------
-- Table `xyz`.`supplier`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`supplier` (
  `SupplierID` INT NOT NULL,
  `SupplierName` VARCHAR(50) NOT NULL,
  `SupplierContactName` VARCHAR(50) NULL,
  `SupplierEmailAddresses` VARCHAR(50) NULL,
  `SupplierContactPerson1` VARCHAR(50) NULL,
  `SupplierContactPerson2` VARCHAR(50) NULL,
  PRIMARY KEY (`SupplierID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`item_category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`item_category` (
  `CategoryCode` VARCHAR(20) NOT NULL,
  `CategoryName` VARCHAR(20) NULL,
  PRIMARY KEY (`CategoryCode`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`inventory`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`inventory` (
  `INV_itemID` INT NOT NULL,
  `INV_itemName` VARCHAR(50) NOT NULL,
  `INV_CostPerItem` DECIMAL(4,2) NULL,
  `INV_QuantityOnShelf` INT NULL,
  `INV_QuantityInStock` INT NULL,
  `INV_ExpectedItemQuota` INT NULL,
  `INV_TotalValueOfItem` DECIMAL(10,2) NULL,
  `INV_CategoryCode` VARCHAR(20) NULL,
  PRIMARY KEY (`INV_itemID`),
  INDEX `inv_category_code_idx` (`INV_CategoryCode` ASC) VISIBLE,
  CONSTRAINT `inv_category_code`
    FOREIGN KEY (`INV_CategoryCode`)
    REFERENCES `xyz`.`item_category` (`CategoryCode`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`customer` (
  `CUS_CustomerID` INT NOT NULL,
  `CUS_CustomerType` VARCHAR(2) NULL,
  PRIMARY KEY (`CUS_CustomerID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`zipCode`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`zipCode` (
  `zipCode` INT NOT NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  `country` VARCHAR(45) NULL,
  PRIMARY KEY (`zipCode`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`emp_address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`emp_address` (
  `addressID` INT NOT NULL,
  `streetName` VARCHAR(50) NULL,
  `zipCode` INT NULL,
  PRIMARY KEY (`addressID`),
  INDEX `emp_address_zipCode_idx` (`zipCode` ASC) VISIBLE,
  CONSTRAINT `emp_address_zipCode`
    FOREIGN KEY (`zipCode`)
    REFERENCES `xyz`.`zipCode` (`zipCode`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`insurance`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`insurance` (
  `INS_InsuranceID` INT NOT NULL,
  `INS_InsuranceName` VARCHAR(45) NOT NULL,
  `INS_AmountofInsuranceEntitled` DECIMAL(10,2) NULL,
  `INS_Expiry_date` DATE NULL,
  `INS_Start_date` DATE NULL,
  PRIMARY KEY (`INS_InsuranceID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`employee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`employee` (
  `EMP_EmployeeID` INT NOT NULL,
  `EMP_FirstName` VARCHAR(50) NOT NULL,
  `EMP_MiddleName` VARCHAR(50) NOT NULL,
  `EMP_LastName` VARCHAR(50) NOT NULL,
  `EMP_Gender` CHAR(2) NULL,
  `EMP_BirthDate` DATE NULL,
  `EMP_Age` INT NULL,
  `EMP_Phone` VARCHAR(50) NULL,
  `EMP_AddressID` INT NULL,
  `EMP_JobLevel` VARCHAR(50) NULL,
  `EMP_annualWage` DECIMAL(10,2) NULL,
  `EMP_Type` CHAR(2) NULL,
  `EMP_InsuranceID` INT NULL,
  `EMP_StartHireDate` DATE NULL,
  `EMP_EndHireDate` DATE NULL,
  `EMP_ShopNumber` VARCHAR(50) NULL,
  PRIMARY KEY (`EMP_EmployeeID`),
  INDEX `EMP_AddressID_idx` (`EMP_AddressID` ASC) VISIBLE,
  INDEX `EMP_InsuranceID_idx` (`EMP_InsuranceID` ASC) VISIBLE,
  CONSTRAINT `EMP_AddressID`
    FOREIGN KEY (`EMP_AddressID`)
    REFERENCES `xyz`.`emp_address` (`addressID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `EMP_InsuranceID`
    FOREIGN KEY (`EMP_InsuranceID`)
    REFERENCES `xyz`.`insurance` (`INS_InsuranceID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`tran_saction`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`tran_saction` (
  `TRAN_ReceiptNo` INT NOT NULL AUTO_INCREMENT,
  `TRAN_WhoPurchased` INT NULL,
  `TRAN_DateTime` DATETIME NULL,
  `TRAN_WhoServedCustomer` INT NULL,
  `TRAN_TotalSales` DECIMAL(10,2) NULL DEFAULT 0.00,
  PRIMARY KEY (`TRAN_ReceiptNo`),
  INDEX `tran_CUSID_idx` (`TRAN_WhoPurchased` ASC) VISIBLE,
  INDEX `tran_empID_idx` (`TRAN_WhoServedCustomer` ASC) VISIBLE,
  CONSTRAINT `tran_CUSID`
    FOREIGN KEY (`TRAN_WhoPurchased`)
    REFERENCES `xyz`.`customer` (`CUS_CustomerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `tran_empID`
    FOREIGN KEY (`TRAN_WhoServedCustomer`)
    REFERENCES `xyz`.`employee` (`EMP_EmployeeID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`individual`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`individual` (
  `CUS_CustomerID` INT NOT NULL,
  `CUS_FirstName` VARCHAR(50) NULL,
  `CUS_MiddleName` VARCHAR(50) NULL,
  `CUS_LastName` VARCHAR(50) NULL,
  `CUS_BirthDate` DATE NULL,
  `CUS_PhoneNumber` VARCHAR(50) NULL,
  `rewardsProgram_membership_status` TINYINT NULL,
  PRIMARY KEY (`CUS_CustomerID`),
  CONSTRAINT `CustomerID`
    FOREIGN KEY (`CUS_CustomerID`)
    REFERENCES `xyz`.`customer` (`CUS_CustomerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`coporate_customer_address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`coporate_customer_address` (
  `addressID` INT NOT NULL,
  `streetName` VARCHAR(45) NULL,
  `zipCode` INT NULL,
  PRIMARY KEY (`addressID`),
  INDEX `cus_address_zipCode_idx` (`zipCode` ASC) VISIBLE,
  CONSTRAINT `cus_address_zipCode`
    FOREIGN KEY (`zipCode`)
    REFERENCES `xyz`.`zipCode` (`zipCode`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`corporate`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`corporate` (
  `CUS_CustomerID` INT NOT NULL,
  `OrganizationName` VARCHAR(50) NULL,
  `authorisedNames` VARCHAR(50) NULL,
  `addressID` INT NULL,
  `contactNumber1` VARCHAR(50) NULL,
  `contactNumber2` VARCHAR(50) NULL,
  `paymentTerms` VARCHAR(2) NULL,
  `specialDiscounts` INT NULL,
  PRIMARY KEY (`CUS_CustomerID`),
  INDEX `addressID_idx` (`addressID` ASC) VISIBLE,
  CONSTRAINT `corp_CustomerID`
    FOREIGN KEY (`CUS_CustomerID`)
    REFERENCES `xyz`.`customer` (`CUS_CustomerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `addressID`
    FOREIGN KEY (`addressID`)
    REFERENCES `xyz`.`coporate_customer_address` (`addressID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`shop_address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`shop_address` (
  `addressID` INT NOT NULL,
  `streetName` VARCHAR(45) NULL,
  `zipCode` INT NULL,
  PRIMARY KEY (`addressID`),
  INDEX `shp_address_zipCode_idx` (`zipCode` ASC) VISIBLE,
  CONSTRAINT `shp_address_zipCode`
    FOREIGN KEY (`zipCode`)
    REFERENCES `xyz`.`zipCode` (`zipCode`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`shop`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`shop` (
  `UniqueShopNumber` VARCHAR(50) NOT NULL,
  `ShopName` VARCHAR(50) NULL,
  `ShopAddressID` INT NULL,
  PRIMARY KEY (`UniqueShopNumber`),
  INDEX `shop_addressID_idx` (`ShopAddressID` ASC) VISIBLE,
  CONSTRAINT `shop_addressID`
    FOREIGN KEY (`ShopAddressID`)
    REFERENCES `xyz`.`shop_address` (`addressID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`asset`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`asset` (
  `AssetID` INT NOT NULL,
  `AssetName` VARCHAR(50) NOT NULL,
  `AssetQuantity` INT NULL,
  `UniqueShopNumber` VARCHAR(50) NULL,
  PRIMARY KEY (`AssetID`),
  INDEX `UniqueShopNumber_idx` (`UniqueShopNumber` ASC) VISIBLE,
  CONSTRAINT `UniqueShopNumber`
    FOREIGN KEY (`UniqueShopNumber`)
    REFERENCES `xyz`.`shop` (`UniqueShopNumber`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`supervisor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`supervisor` (
  `EmployeeID` INT NOT NULL,
  `Wages` DECIMAL(10,2) UNSIGNED NULL,
  `hoursWorked` INT NULL,
  `totalPay` DECIMAL(10,2) UNSIGNED NULL,
  `wageRate` DECIMAL(4,2) UNSIGNED NULL,
  `WorkLocation` VARCHAR(50) NULL DEFAULT 'Inventory',
  PRIMARY KEY (`EmployeeID`),
  CONSTRAINT `supervisor_EMP_EmployeeID`
    FOREIGN KEY (`EmployeeID`)
    REFERENCES `xyz`.`employee` (`EMP_EmployeeID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`trainee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`trainee` (
  `EmployeeID` INT NOT NULL,
  `Wages` DECIMAL(10,2) UNSIGNED NULL,
  `hoursWorked` INT NULL,
  `totalPay` DECIMAL(10,2) UNSIGNED NULL,
  `wageRate` DECIMAL(4,2) UNSIGNED NULL,
  `WorkLocation` VARCHAR(50) NULL DEFAULT 'Inventory',
  PRIMARY KEY (`EmployeeID`),
  CONSTRAINT `trainee_EMP_EmployeeID`
    FOREIGN KEY (`EmployeeID`)
    REFERENCES `xyz`.`employee` (`EMP_EmployeeID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`cashier`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`cashier` (
  `EmployeeID` INT NOT NULL,
  `Wages` DECIMAL(10,2) UNSIGNED NULL,
  `hoursWorked` INT NULL,
  `totalPay` DECIMAL(10,2) UNSIGNED NULL,
  `wageRate` DECIMAL(4,2) UNSIGNED NULL,
  `WorkLocation` VARCHAR(50) NULL DEFAULT 'Counter',
  PRIMARY KEY (`EmployeeID`),
  CONSTRAINT `cashier_EMP_ID`
    FOREIGN KEY (`EmployeeID`)
    REFERENCES `xyz`.`employee` (`EMP_EmployeeID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`product_supplier`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`product_supplier` (
  `ItemID` INT NOT NULL,
  `SupplierID` INT NOT NULL,
  INDEX `ItemID_idx` (`ItemID` ASC) VISIBLE,
  INDEX `SupplierID_idx` (`SupplierID` ASC) VISIBLE,
  PRIMARY KEY (`ItemID`, `SupplierID`),
  CONSTRAINT `ItemID`
    FOREIGN KEY (`ItemID`)
    REFERENCES `xyz`.`inventory` (`INV_itemID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `SupplierID`
    FOREIGN KEY (`SupplierID`)
    REFERENCES `xyz`.`supplier` (`SupplierID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`customer_visits`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`customer_visits` (
  `CUS_CustomerID` INT NOT NULL,
  `ShopNo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`CUS_CustomerID`, `ShopNo`),
  INDEX `ShopNo_idx` (`ShopNo` ASC) VISIBLE,
  CONSTRAINT `visits_CUS_CustomerID`
    FOREIGN KEY (`CUS_CustomerID`)
    REFERENCES `xyz`.`customer` (`CUS_CustomerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `ShopNo`
    FOREIGN KEY (`ShopNo`)
    REFERENCES `xyz`.`shop` (`UniqueShopNumber`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`clerkType`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`clerkType` (
  `clerkType` CHAR(20) NOT NULL,
  `wageRate` DECIMAL(4,2) UNSIGNED NULL,
  `WorkLocation` VARCHAR(50) NULL DEFAULT 'Office',
  PRIMARY KEY (`clerkType`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`clerk`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`clerk` (
  `EmployeeID` INT NOT NULL,
  `clerkType` CHAR(20) NULL,
  `hoursWorked` INT NULL DEFAULT 0,
  `Wages` DECIMAL(10,2) NULL DEFAULT 0,
  `totalPay` DECIMAL(10,2) NULL DEFAULT 0,
  PRIMARY KEY (`EmployeeID`),
  INDEX `clerkType_idx` (`clerkType` ASC) VISIBLE,
  CONSTRAINT `clerk_EMP_EmployeeID`
    FOREIGN KEY (`EmployeeID`)
    REFERENCES `xyz`.`employee` (`EMP_EmployeeID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `clerkType`
    FOREIGN KEY (`clerkType`)
    REFERENCES `xyz`.`clerkType` (`clerkType`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`manager`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`manager` (
  `EmployeeID` INT NOT NULL,
  `Wages` DECIMAL(10,2) UNSIGNED NULL DEFAULT 0,
  `hoursWorked` INT UNSIGNED NULL DEFAULT 0,
  `totalPay` DECIMAL(10,2) UNSIGNED NULL DEFAULT 0,
  `wageRate` DECIMAL(4,2) UNSIGNED NULL,
  `WorkLocation` VARCHAR(50) NULL DEFAULT 'Office',
  PRIMARY KEY (`EmployeeID`),
  CONSTRAINT `manager_EMP_EmployeeID`
    FOREIGN KEY (`EmployeeID`)
    REFERENCES `xyz`.`employee` (`EMP_EmployeeID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`shop_inventory`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`shop_inventory` (
  `UniqueShopNumber` VARCHAR(50) NOT NULL,
  `ItemID` INT NULL,
  INDEX `ItemID_idx` (`ItemID` ASC) VISIBLE,
  PRIMARY KEY (`UniqueShopNumber`),
  CONSTRAINT `shpINV_UniqueShopNumber`
    FOREIGN KEY (`UniqueShopNumber`)
    REFERENCES `xyz`.`shop` (`UniqueShopNumber`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `shpINV_ItemID`
    FOREIGN KEY (`ItemID`)
    REFERENCES `xyz`.`inventory` (`INV_itemID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`items_purchased`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`items_purchased` (
  `ReceiptNumber` INT NOT NULL,
  `ItemID` INT NOT NULL,
  `Quantity` INT NULL DEFAULT 0,
  `TotalCost` DECIMAL(10,2) NULL,
  PRIMARY KEY (`ReceiptNumber`, `ItemID`),
  INDEX `ItemID_idx` (`ItemID` ASC) VISIBLE,
  CONSTRAINT `itmPUR_ReceiptNumber`
    FOREIGN KEY (`ReceiptNumber`)
    REFERENCES `xyz`.`tran_saction` (`TRAN_ReceiptNo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `itmPUR_ItemID`
    FOREIGN KEY (`ItemID`)
    REFERENCES `xyz`.`inventory` (`INV_itemID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`purchaseOrders`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`purchaseOrders` (
  `orderID` INT NOT NULL AUTO_INCREMENT,
  `CustomerID` INT NULL,
  `OrderDate` DATE NULL,
  PRIMARY KEY (`orderID`),
  INDEX `ord_CustomerID_idx` (`CustomerID` ASC) VISIBLE,
  CONSTRAINT `ord_CustomerID`
    FOREIGN KEY (`CustomerID`)
    REFERENCES `xyz`.`corporate` (`CUS_CustomerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`orderItems`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`orderItems` (
  `orderID` INT NOT NULL,
  `ItemID` INT NOT NULL,
  `Quantity` INT NULL,
  `TotalCost` DECIMAL(10,2) NULL,
  PRIMARY KEY (`orderID`, `ItemID`),
  INDEX `orderITEMS_ItemID_idx` (`ItemID` ASC) VISIBLE,
  CONSTRAINT `orderITEMS_OrderID`
    FOREIGN KEY (`orderID`)
    REFERENCES `xyz`.`purchaseOrders` (`orderID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `orderITEMS_ItemID`
    FOREIGN KEY (`ItemID`)
    REFERENCES `xyz`.`inventory` (`INV_itemID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`invoice`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`invoice` (
  `invoiceNumber` INT NOT NULL AUTO_INCREMENT,
  `OrderID` INT NULL,
  `totalSales` DECIMAL(10,2) NULL DEFAULT 0,
  `DiscountAmount` DECIMAL(10,2) NULL DEFAULT 0,
  `totalOutstanding` DECIMAL(10,2) NULL DEFAULT 0,
  `AmountPaid` DECIMAL(10,2) NULL DEFAULT 0,
  `PaymentStatus` VARCHAR(20) NULL DEFAULT 'not paid',
  `InvoicedBy` INT NULL,
  PRIMARY KEY (`invoiceNumber`),
  INDEX `INV_OrderID_idx` (`OrderID` ASC) VISIBLE,
  CONSTRAINT `INV_OrderID`
    FOREIGN KEY (`OrderID`)
    REFERENCES `xyz`.`purchaseOrders` (`orderID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `xyz`.`paynow`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `xyz`.`paynow` (
  `idpaynow` INT NOT NULL,
  PRIMARY KEY (`idpaynow`))
ENGINE = InnoDB;

USE `xyz`;

DELIMITER $$
USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`inventory_BEFORE_INSERT` BEFORE INSERT ON `inventory` FOR EACH ROW
BEGIN
	IF(new.INV_itemID not like "")
    AND(new.INV_itemName not like "")
    AND(new.INV_CostPerItem not like 0)
    AND(new.INV_QuantityOnShelf not like 0)
    AND(new.INV_QuantityInStock not like 0)
    AND(new.INV_ExpectedItemQuota not like 0)
    AND(new.INV_CategoryCode not like "")
    THEN
		set new.INV_itemID = new.INV_itemID;
        set new.INV_itemName = new.INV_itemName;
        set new.INV_CostPerItem = new.INV_CostPerItem;
        set new.INV_QuantityOnShelf = new.INV_QuantityOnShelf;
        set new.INV_QuantityInStock = new.INV_QuantityInStock;
        set new.INV_ExpectedItemQuota = new.INV_ExpectedItemQuota;
        set new.INV_CategoryCode = new.INV_CategoryCode;
		set new.INV_TotalValueOfItem = (new.INV_QuantityOnShelf+new.INV_QuantityInStock) * new.INV_CostPerItem * 1.00;
        else
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error! TRANS_TotalSales is a Caculated Field';
        END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`inventory_BEFORE_UPDATE` BEFORE UPDATE ON `inventory` FOR EACH ROW
BEGIN
	IF(new.INV_QuantityOnShelf not like old.INV_QuantityOnShelf)
    THEN
		set new.INV_TotalValueOfItem = (new.INV_QuantityOnShelf+old.INV_QuantityInStock) * old.INV_CostPerItem;
	ELSEIF(new.INV_QuantityInStock not like old.INV_QuantityInStock)
    THEN
		set new.INV_TotalValueOfItem = (new.INV_QuantityInStock+old.INV_QuantityOnShelf) * old.INV_CostPerItem;
    END IF;
END$$

USE `xyz`$$
CREATE TRIGGER `customer_AFTER_INSERT` AFTER INSERT ON `customer` FOR EACH ROW
BEGIN
	IF (NEW.CUS_CustomerType like "IL")
    THEN
		INSERT INTO individual(CUS_CustomerID) values (NEW.CUS_CustomerID);
	ELSEIF (NEW.CUS_CustomerType like "CE")
    THEN
		INSERT INTO corporate(CUS_CustomerID,addressID) values (NEW.CUS_CustomerID,3100);
	END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`employee_checkHireNStartDate` BEFORE INSERT ON `employee` FOR EACH ROW
BEGIN
	-- since the check constraint has some version bugs, i chose to implement a before insert trigger
	IF (NEW.EMP_EndHireDate < NEW.EMP_StartHireDate) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'end_date cannot be earlier than start_date';
	END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`employee_calculateAge` BEFORE INSERT ON `employee` FOR EACH ROW
BEGIN
	DECLARE AgeString VARCHAR(5);
	set AgeString = (SELECT DATE_FORMAT(FROM_DAYS(DATEDIFF(now(),new.EMP_BirthDate)), '%Y')+0);
	set new.EMP_Age = CAST( AgeString AS signed);
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`employee_checkEmpType` BEFORE INSERT ON `employee` FOR EACH ROW
BEGIN
	
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`employee_AFTER_INSERT` AFTER INSERT ON `employee` FOR EACH ROW
BEGIN
IF (NEW.EMP_Type like "MR")
    THEN
		INSERT INTO xyz.manager(EmployeeID,wageRate) values(NEW.EMP_EmployeeID,40.00);
	ELSEIF (NEW.EMP_Type like "CK")
    THEN
		INSERT INTO xyz.clerk(EmployeeID) values(NEW.EMP_EmployeeID);
	ELSEIF (NEW.EMP_Type like "SR")
    THEN
		INSERT INTO xyz.supervisor(EmployeeID,wageRate) values(NEW.EMP_EmployeeID,20.00);
	ELSEIF (NEW.EMP_Type like "TE")
    THEN 
		INSERT INTO xyz.trainee(EmployeeID,wageRate) values(NEW.EMP_EmployeeID,5.00);
	ELSEIF (NEW.EMP_Type like "CR")
    THEN
		INSERT INTO xyz.cashier(EmployeeID,wageRate) values(NEW.EMP_EmployeeID,10.00);
	else
		delete from employee where EMP_EmployeeID = new.EMP_EmployeeID;
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot Insert emp_type domain{MR, CK, SR, TE, CR}';
    END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`tran_saction_AFTER_INSERT` AFTER INSERT ON `tran_saction` FOR EACH ROW
BEGIN
	DECLARE shopNo VARCHAR(45);
    DECLARE checkCus INT;
    set checkCus = (select CUS_CustomerID from customer_visits where CUS_CustomerID = new.TRAN_WhoPurchased);
    set shopNo = (Select EMP_ShopNumber from employee where EMP_EmployeeID = new.TRAN_WhoServedCustomer);
	IF(new.TRAN_WhoPurchased not like 0)AND(checkCus not like null)
    THEN
		insert into customer_visits(CUS_CustomerID,ShopNo) values
        (new.TRAN_WhoPurchased,shopNo);
    END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`tran_saction_BEFORE_UPDATE` BEFORE UPDATE ON `tran_saction` FOR EACH ROW
BEGIN
	DECLARE Temp DECIMAL(10,2);
	IF(old.TRAN_ReceiptNo <=> new.TRAN_ReceiptNo)
    AND(old.TRAN_WhoPurchased <=> new.TRAN_ReceiptNo)
    AND(old.TRAN_DateTime <=> new.TRAN_DateTime)
    AND(old.TRAN_WhoServedCustomer <=> new.TRAN_WhoServedCustomer)
    AND(new.TRAN_TotalSales > 0)
    THEN
    set new.TRAN_TotalSales = new.TRAN_TotalSales;
    END IF;
    
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`corporate_BEFORE_UPDATE` BEFORE UPDATE ON `corporate` FOR EACH ROW
BEGIN
	IF(new.paymentTerms not like "")
    THEN
    	IF(new.paymentTerms like "PN")
        OR(new.paymentTerms like "PL")
        THEN
			SET new.paymentTerms = new.paymentTerms;
		else
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Payment Terms Takes in PL-Pay Later | PN-Pay Now';
        END IF;
	END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`shop_BEFORE_INSERT` BEFORE INSERT ON `shop` FOR EACH ROW
BEGIN
	IF(new.UniqueShopNumber not like "")
    THEN
		IF(new.UniqueShopNumber not rlike '[X][Y][Z][0-9]{3}')
        THEN
        SIGNAL SQLSTATE '12345' SET MESSAGE_TEXT = 'Your Input can contain only [XYZ][0-9]{3}!';
        END IF;
    END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`supervisor_BEFORE_UPDATE` BEFORE UPDATE ON `supervisor` FOR EACH ROW
BEGIN
	DECLARE rate DECIMAL(4,2); 
    if (new.hoursWorked > 0)
    AND(old.EmployeeID <=> new.EmployeeID)
    AND(old.Wages <=> new.Wages)
    AND(old.totalPay <=> new.totalPay)
    AND(old.wageRate <=> new.wageRate)
    then
		set rate = (select wageRate from supervisor where EmployeeID = old.EmployeeID);
		set new.Wages = new.hoursWorked * rate;
        set new.totalPay = new.hoursWorked * rate;
		UPDATE employee set EMP_annualWage = new.hoursWorked * rate * 26 where EMP_EmployeeID = old.EmployeeID;

	elseif (old.EmployeeID <=> new.EmployeeID)
    AND(old.Wages <=> new.Wages)
    AND(old.hoursWorked <=> new.hoursWorked)
    AND(old.totalPay <=> new.Wages)
    AND(new.wageRate > 0 )
    then
		set new.wageRate = new.wageRate;
		set new.Wages = new.hoursWorked * new.wageRate;
        set new.totalPay = new.hoursWorked * new.wageRate;
        UPDATE employee set EMP_annualWage = new.hoursWorked * new.wageRate * 26 where EMP_EmployeeID = old.EmployeeID;
	else
    		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CALCULATED field! You cannot update this field';
	END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`trainee_BEFORE_UPDATE` BEFORE UPDATE ON `trainee` FOR EACH ROW
BEGIN
	DECLARE rate DECIMAL(4,2); 
    if (new.hoursWorked > 0)
    AND(old.EmployeeID <=> new.EmployeeID)
    AND(old.Wages <=> new.Wages)
    AND(old.totalPay <=> new.Wages)
    AND(old.wageRate <=> new.wageRate)
    then
		set rate = old.wageRate;
		set new.Wages = new.hoursWorked * rate;
        set new.totalPay = new.hoursWorked * rate;
        UPDATE employee set EMP_annualWage = new.hoursWorked * rate * 26 where EMP_EmployeeID = old.EmployeeID;
	elseif (old.EmployeeID <=> new.EmployeeID)
    AND(old.Wages <=> new.Wages)
    AND(old.hoursWorked <=> new.hoursWorked)
    AND(old.totalPay <=> new.Wages)
    AND(new.wageRate > 0 )
    then
		set new.wageRate = new.wageRate;
		set new.Wages = new.hoursWorked * new.wageRate;
        set new.totalPay = new.hoursWorked * new.wageRate;
        UPDATE employee set EMP_annualWage = new.hoursWorked * new.wageRate * 26 where EMP_EmployeeID = old.EmployeeID;
	else
    		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CALCULATED field! You cannot update this field';
	END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`cashier_BEFORE_UPDATE` BEFORE UPDATE ON `cashier` FOR EACH ROW
BEGIN
	DECLARE rate DECIMAL(4,2); 
    if (new.hoursWorked > 0)
    AND(old.EmployeeID <=> new.EmployeeID)
    AND(old.Wages <=> new.Wages)
    AND(old.totalPay <=> new.Wages)
    then
		set rate = (select wageRate from cashier where EmployeeID = old.EmployeeID);
		set new.Wages = new.hoursWorked * rate;
        set new.totalPay = new.hoursWorked * rate;
		UPDATE employee set EMP_annualWage = new.hoursWorked * rate * 26 where EMP_EmployeeID = old.EmployeeID;

	elseif (old.EmployeeID <=> new.EmployeeID)
    AND(old.Wages <=> new.Wages)
    AND(old.hoursWorked <=> new.hoursWorked)
    AND(old.totalPay <=> new.Wages)
    AND(new.wageRate > 0 )
    then
		set new.wageRate = new.wageRate;
		set new.Wages = new.hoursWorked * new.wageRate;
        set new.totalPay = new.hoursWorked * new.wageRate;
		UPDATE employee set EMP_annualWage = new.hoursWorked * new.wageRate * 26 where EMP_EmployeeID = old.EmployeeID;

	else
    		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CALCULATED field! You cannot update this field';
	END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`clerk_BEFORE_UPDATE` BEFORE UPDATE ON `clerk` FOR EACH ROW
BEGIN
	DECLARE CKType CHAR(20);
    DECLARE wgRate DECIMAL(4,2);
    set CKType = (select clerkType from clerktype where clerkType = new.clerkType);
	IF(new.clerkType not like CKType)
	THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'clerkType Domain 
        STORE
        INV
        OFF
        FR-OFF';
	elseif(old.EmployeeID <=> new.EmployeeID)
    AND(new.clerkType not like "")
    AND(old.Wages <=> new.Wages)
    AND(old.totalPay <=> new.totalPay)
    AND(new.hoursWorked > 0)
    THEN
    set	wgRate = (select wageRate from clerktype where clerkType = new.clerkType);
	set new.hoursWorked = new.hoursWorked;
    set new.Wages = new.hoursWorked * wgRate;
    set new.totalPay = new.hoursWorked * wgRate;
    UPDATE employee set EMP_annualWage = new.hoursWorked * wgRate * 26 where EMP_EmployeeID = old.EmployeeID;
    
    elseif (old.EmployeeID <=> new.EmployeeID)
    AND(new.clerkType not like "")
    AND(old.Wages <=> new.Wages)
    AND(old.totalPay <=> new.totalPay)
    AND(old.hoursWorked <=> new.hoursWorked)
    THEN
		SET new.clerkType = new.clerkType;
        
	elseif(old.EmployeeID <=> new.EmployeeID)
    AND(new.clerkType not like "")
    AND(old.hoursWorked > 0)
    AND(old.Wages <=> new.Wages)
    AND(old.totalPay <=> new.totalPay)
    THEN
	set	wgRate = (select wageRate from clerktype where clerkType = new.clerkType);
	set new.clerkType = new.clerkType;
    set new.Wages = old.hoursWorked * wgRate;
    set new.totalPay = old.hoursWorked * wgRate;
	UPDATE employee set EMP_annualWage = old.hoursWorked * wgRate * 26 where EMP_EmployeeID = old.EmployeeID;
	END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`manager_BEFORE_UPDATE` BEFORE UPDATE ON `manager` FOR EACH ROW
BEGIN
	DECLARE rate DECIMAL(4,2); 
    if (new.hoursWorked > 0)
    AND(old.EmployeeID <=> new.EmployeeID)
    AND(old.Wages <=> new.Wages)
    AND(old.totalPay <=> new.Wages)
    then
		set rate = (select wageRate from manager where EmployeeID = old.EmployeeID);
		set new.Wages = new.hoursWorked * rate;
        UPDATE employee set EMP_annualWage = new.hoursWorked * rate * 26 where EMP_EmployeeID = old.EmployeeID;
        set new.totalPay = new.hoursWorked * rate;
	elseif (old.EmployeeID <=> new.EmployeeID)
    AND(old.Wages <=> new.Wages)
    AND(old.hoursWorked <=> new.hoursWorked)
    AND(old.totalPay <=> new.Wages)
    AND(new.wageRate > 0 )
    then
		set new.wageRate = new.wageRate;
		set new.Wages = old.hoursWorked * new.wageRate;
        set new.totalPay = old.hoursWorked * new.wageRate;
        UPDATE employee set EMP_annualWage = old.hoursWorked * new.wageRate * 26 where EmployeeID = old.EmployeeID;
	else
    		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CALCULATED field! You cannot update this field';
	END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`items_purchased_BEFORE_INSERT` BEFORE INSERT ON `items_purchased` FOR EACH ROW
BEGIN
	DECLARE costPerItem DECIMAL(4,2);
    DECLARE NoOfItemOnShelf INT;
    DECLARE stkCountNew INT;
    DECLARE QNTY INT;
    declare Temp DECIMAL(10,2);
    DECLARE TCost DECIMAL(4,2);
	IF(new.Quantity not like 0)
    THEN
		set QNTY = NEW.Quantity;
		set costPerItem = (SELECT INV_CostPerItem from inventory where INV_itemID = NEW.ItemID);
		set TCost = QNTY * costPerItem;
		set new.TotalCost = TCost;
        
		set NoOfItemOnShelf = (select INV_QuantityOnShelf from inventory where INV_itemID = new.ItemID);
		set stkCountNew = NoOfItemOnShelf - QNTY;
        UPDATE inventory SET INV_QuantityOnShelf = stkCountNew where INV_itemID = new.ItemID;
        set Temp = (select TRAN_TotalSales from tran_saction where TRAN_ReceiptNo = new.ReceiptNumber);
        update tran_saction set TRAN_TotalSales = TCost+Temp where TRAN_ReceiptNo = new.ReceiptNumber;
    END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`orderItems_BEFORE_INSERT` BEFORE INSERT ON `orderItems` FOR EACH ROW
BEGIN
	DECLARE costPerItem DECIMAL(4,2);
    DECLARE NoOfItem INT;
    DECLARE stkCountNew INT;
    DECLARE QNTY INT;
    declare Temp DECIMAL(10,2);
    DECLARE TCost DECIMAL(10,2);
	IF(new.Quantity not like 0)
    THEN
		set QNTY = NEW.Quantity;
		set costPerItem = (SELECT INV_CostPerItem from inventory where INV_itemID = NEW.ItemID);
		set TCost = QNTY * costPerItem;
		set new.TotalCost = TCost;
        
		set NoOfItem = (select INV_QuantityInStock from inventory where INV_itemID = new.ItemID);
		set stkCountNew = NoOfItem - QNTY;
        UPDATE inventory SET INV_QuantityInStock = stkCountNew where INV_itemID = new.ItemID;
        set Temp = (select totalSales from invoice where OrderID = new.OrderID);
        update invoice set totalSales = TCost+Temp where OrderID = new.OrderID;
    END IF;
END$$

USE `xyz`$$
CREATE DEFINER = CURRENT_USER TRIGGER `xyz`.`invoice_AFTER_INSERT` AFTER INSERT ON `invoice` FOR EACH ROW
BEGIN
	 declare CUSID int;
    declare shopNo VARCHAR(45);
    set shopNo = (Select EMP_ShopNumber from employee where EMP_EmployeeID = new.InvoicedBy);
    set CUSID = (Select CustomerID from purchaseorders where orderID = new.OrderID);
	insert into customer_visits(CUS_CustomerID,ShopNo) values
	(CUSID,shopNo);
END$$

USE `xyz`$$
CREATE TRIGGER `xyz`.`invoice_BEFORE_UPDATE` BEFORE UPDATE ON `invoice` FOR EACH ROW
BEGIN
	DECLARE initCost DECIMAL(10,2);
    DECLARE newCost DECIMAL(10,2);
    DECLARE discount INT;
    DECLARE cusID INT;
	IF(old.invoiceNumber <=> new.invoiceNumber)
    AND(old.OrderID <=> new.OrderID)
    AND(old.AmountPaid <=> new.AmountPaid)
    AND(old.PaymentStatus <=> new.PaymentStatus)
    AND(old.InvoicedBy <=> new.InvoicedBy)
    AND(new.totalSales > 0)
    THEN
		set cusID = (select customerID from purchaseorders where orderID = old.orderID);
		set discount = (select specialDiscounts from corporate where CUS_CustomerID = cusID);
        set newCost = new.totalSales;
        set new.totalSales = newCost;
        set new.DiscountAmount = (discount/100.00 * newCost);
        set new.totalOutstanding = newCost - (discount/100.00 * newCost);
	ELSEIF(old.invoiceNumber <=> new.invoiceNumber)
    AND(old.OrderID <=> new.OrderID)
    AND(old.totalOutstanding <=> new.totalOutstanding)
    AND(old.PaymentStatus <=> new.PaymentStatus)
    AND(old.InvoicedBy <=> new.InvoicedBy)
    AND(new.AmountPaid > 0)
    THEN
		set new.AmountPaid = new.AmountPaid;
        set new.totalOutstanding = old.totalOutstanding - new.AmountPaid;
    END IF;
END$$

USE `xyz`$$
CREATE TRIGGER `xyz`.`invoice_updatePayterms` BEFORE UPDATE ON `invoice` FOR EACH ROW
BEGIN
	DECLARE PaidCus INT;
	IF (new.totalOutstanding = 0)
    THEN
		set PaidCus = (select CustomerID from purchaseorders where orderID = new.orderID);
		set new.PaymentStatus = "Paid";
        insert into tran_saction (TRAN_WhoPurchased,TRAN_DateTime,TRAN_WhoServedCustomer,TRAN_TotalSales) 
        values(PaidCus,curdate(),new.InvoicedBy,new.AmountPaid);
	END IF;
END$$


DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
