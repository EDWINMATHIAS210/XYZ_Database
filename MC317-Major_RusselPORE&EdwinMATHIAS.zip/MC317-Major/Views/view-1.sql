CREATE VIEW query1 AS
SELECT
  inventory.INV_itemID AS `Item ID`,
  inventory.INV_itemName AS `Item Name`,
  inventory.INV_QuantityOnShelf AS `Quantity On Shelf`,
  inventory.INV_QuantityInStock AS `Quantity in Stock`,
  inventory.INV_ExpectedItemQuota AS `Expected Item Quota`,
  inventory.INV_TotalValueOfItem AS `Total Value of Item (K)`,
  item_category.CategoryName AS `Category Name`
FROM inventory
  LEFT OUTER JOIN orderitems
    ON inventory.INV_itemID = orderitems.ItemID
  INNER JOIN item_category
    ON inventory.INV_CategoryCode = item_category.CategoryCode
WHERE orderitems.ItemID IS NULL;