CREATE VIEW query6 AS
SELECT
  corporate.OrganizationName AS `Organization Name`,
  corporate.contactNumber1 AS `Contact Number`,
  corporate.specialDiscounts AS `Special Discounts (%)`,
  corporate.paymentTerms AS `Payment Terms`,
  invoice.totalOutstanding AS `Total Outstanding (K)`,
  invoice.AmountPaid AS `Amount Paid (K)`
FROM invoice,
     corporate
       LEFT OUTER JOIN purchaseorders
         ON corporate.CUS_CustomerID = purchaseorders.CustomerID;