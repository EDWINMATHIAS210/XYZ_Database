CREATE VIEW query7 AS
SELECT
  employee.EMP_FirstName AS `First Name`,
  employee.EMP_LastName AS `Last Name`,
  employee.EMP_Age AS Age,
  employee.EMP_BirthDate AS `Birth Date`,
  employee.EMP_Type AS `Employee Type`,
  insurance.INS_InsuranceName AS `Insurance Name`,
  insurance.INS_AmountofInsuranceEntitled AS `Entitled Insurance Amount (K)`
FROM employee
  INNER JOIN insurance
    ON employee.EMP_InsuranceID = insurance.INS_InsuranceID;