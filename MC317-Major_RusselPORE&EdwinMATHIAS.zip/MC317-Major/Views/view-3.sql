CREATE VIEW query3 AS
SELECT
  tran_saction.TRAN_DateTime AS `Transaction Date`,
  inventory.INV_itemName AS `Item Name`,
  customer.CUS_CustomerID AS `Customer ID`,
  tran_saction.TRAN_TotalSales AS `Total Sales (K)`,
  items_purchased.TotalCost AS `Total Cost (K)`
FROM items_purchased
  RIGHT OUTER JOIN tran_saction
    ON items_purchased.ReceiptNumber = tran_saction.TRAN_ReceiptNo
  LEFT OUTER JOIN customer
    ON tran_saction.TRAN_WhoPurchased = customer.CUS_CustomerID
  NATURAL JOIN inventory
WHERE inventory.INV_itemName LIKE "Rice%";