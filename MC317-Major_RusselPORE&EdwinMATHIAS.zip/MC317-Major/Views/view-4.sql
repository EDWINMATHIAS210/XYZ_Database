CREATE VIEW query4 AS
SELECT
  inventory.INV_itemName AS `Item Name`,
  item_category.CategoryName AS `Category Name`,
  inventory.INV_QuantityInStock AS `Quantity in Stock`,
  inventory.INV_CostPerItem AS `Cost/Item (K)`
FROM inventory,
     item_category
ORDER BY `Cost/Item (K)` DESC
LIMIT 5