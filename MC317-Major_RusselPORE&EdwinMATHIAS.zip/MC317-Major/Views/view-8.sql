CREATE VIEW query8 AS
SELECT
  inventory.INV_itemID AS `Item ID`,
  inventory.INV_itemName AS `Item Name`,
  inventory.INV_QuantityOnShelf AS `Quantity on Shelf`,
  inventory.INV_QuantityInStock AS `Quantity in Stock`,
  inventory.INV_TotalValueOfItem AS `Total Value of Item (K)`,
  inventory.INV_ExpectedItemQuota AS `Expected Item Quota`
FROM inventory;