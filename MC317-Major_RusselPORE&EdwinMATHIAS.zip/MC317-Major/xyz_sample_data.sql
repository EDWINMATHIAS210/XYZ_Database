use xyz;
-- addresses
insert into zipcode(zipcode,city,state,country) values 
(211,"Alotau","Milne Bay","Papua New Guinea");



-- shop
insert into shop_address(addressID,streetName,zipCode) values
	(4100,"Bottom Town",211);

insert into shop(UniqueShopNumber,ShopName,ShopAddressID) values
	("XYZ000","Xyz 1",4100);

insert into asset(AssetID,AssetName,AssetQuantity,UniqueShopNumber) values
	(7000,"VEHICLE-Toyota-PickUp",10,"XYZ000"),
	(7001,"FORKLIFT-CAT-Mini",10,"XYZ000"),
	(7002,"VEHICLE-Toyota-Cargo",10,"XYZ000");


-- supplier
insert into supplier(SupplierID,SupplierName,SupplierContactName,SupplierEmailAddresses,SupplierContactPerson1,SupplierContactPerson2) values
	(5000,"Paradise Foods","ParadiseFoods","paradisefoods@gmail.com","Mark Henry","Jason Smith"),
	(5001,"Nestle","Nestle","nestle@gmail.com","Timothy Green","Luke Martin"),
	(5002,"Brian Bell","BrianBell","brianbell@gmail.com","Luke Mason","Jeremy Nathan"),
	(5003,"Zenag","Zenag","zenag@gmail.com","Cody John","Manuel Dickson"),
	(5004,"Ramu","Ramu","ramu@gmail.com","Chris Mark","Jimmy Tom"),
	(5005,"Coca Cola","Cocacola","ccl@gmail.com","Shane Luke","Kyle Arthur"),
	(5006,"Nescafe","Nescafe","nescafe@gmail.com","Louis Tim","Mark Eddie"),
	(5007,"RD Tuna","RDTuna","rdtuna@gmail.com","Theresa Mason","Lucas Moses"),
	(5008,"Hugo Canning","HugoCanning","hugocanning@gmail.com","John Smith","Isaac Tom"),
	(5009,"Trukai Industries","Trukai","trukai@gmail.com","Jane Payne","Wilson Ramsy");



-- inventory
insert into item_category(CategoryCode,CategoryName) values
	("FD","FOOD"),
	("DR","DRINK");

insert into inventory(INV_itemID,INV_itemName,INV_CostPerItem,INV_QuantityOnShelf,INV_QuantityInStock,INV_ExpectedItemQuota,INV_CategoryCode) values
(1000,"Tin Fish-small-Diana",2.50,200,300,70,"FD"),
(1001,"Rice-1kg-Trukai",5.00,200,300,80,"FD"),
(1002,"Sugar-1kg-Ramu",4.30,400,100,50,"FD"),
(1003,"Coke-330mL",2.50,200,200,60,"DR"),
(1004,"Biscuit-Snax-1",1.20,400,200,50,"FD"),
(1005,"Biscuit-EmNau-1",1.20,400,200,60,"FD"),
(1006,"Coke-500mL",4.90,400,200,60,"FD"),
(1007,"Rice-500g-Trukai",3.20,400,200,60,"FD"),
(1008,"Rice-5kg-Trukai",30.50,400,200,60,"FD"),
(1009,"Rice-10kg-Trukai",48.20,400,200,60,"FD"),
(1010,"Sprite-330mL",2.50,400,200,60,"DR"),
(1011,"Sprite-500mL",4.90,400,200,60,"DR"),
(1012,"Sprite-1L",7.20,400,200,60,"DR"),
(1013,"Coffee-3in1-Nescafe",1.10,400,200,60,"FD"),
(1014,"Coffee-300g-Nescafe",3.20,400,200,60,"FD"),
(1015,"Butter-10g-Anchor",3.50,400,200,60,"FD"),
(1016,"Milk-1L-Pauls",8.90,400,200,60,"DR"),
(1017,"Milk-150mL-Pauls",3.20,400,200,60,"DR"),
(1018,"Eggs-12-Zenag",3.20,400,200,60,"FD"),
(1019,"Eggs-6-Zenag",3.20,400,200,60,"FD"),
(1020,"Meat-Chicken-Pieces-1kg-Zenag",15.20,400,200,60,"FD"),
(1021,"Meat-Chicken-Wings-1kg-Zenag",16.50,400,200,60,"FD"),
(1022,"Meat-Chicken-DrumSticks-1kg-Zenag",17.30,400,200,60,"FD"),
(1023,"Flour-1kg-Plain-Flame",9.60,400,200,60,"FD"),
(1024,"Flour-1kg-SelfRaising-Flame",10.20,400,200,60,"FD");
-- supplier inventory
insert into product_supplier(ItemID,SupplierID) values
	(1000,5007),
	(1001,5009),
	(1002,5004),
	(1003,5005),
	(1004,5000),
	(1005,5000),
	(1006,5005),
	(1007,5009),
	(1008,5009),
	(1009,5009),
	(1010,5005),
	(1011,5005),
	(1012,5005),
	(1013,5006),
	(1014,5006),
	(1015,5002),
	(1016,5002),
	(1017,5002),
	(1018,5003),
	(1019,5003),
	(1020,5002),
	(1021,5002),
	(1022,5002),
	(1023,5002),
	(1024,5002);


-- employee

insert into emp_address(addressID,StreetName,zipCode) values
(100,"PukPuk Street",211),
(101,"Banana Street",211),
(102,"Paradise Street",211)
;

insert into insurance(INS_InsuranceID,INS_InsuranceName,INS_AmountofInsuranceEntitled,INS_Expiry_date,INS_Start_date) values
(100,"Tom's Insurance",10000,"2024-08-12","2019-12-14");

insert into clerkType(clerkType,wageRate,WorkLocation) values
("STORE",15,"Inventory"),
("INV",15.50,"Inventory"),
("OFF",14.00,"Inventory"),
("FR-OFF",13.50,"Inventory");

insert into employee(EMP_EmployeeID,EMP_FirstName,EMP_MiddleName,EMP_LastName,EMP_Gender,EMP_BirthDate,EMP_Phone,EMP_AddressID,EMP_JobLevel,EMP_Type,EMP_InsuranceID,EMP_StartHireDate,EMP_EndHireDate,EMP_ShopNumber) values
(200,"John","Tom","SMITH","M","1980-12-15","+675 70024512",100,"Managerial",'MR',100,"2022-06-15","2023-06-15","XYZ000"),
(201,"Michael","","BATEMAN","M","1981-10-03","+675 74553221",100,"Managerial",'MR',100,"2022-05-12","2023-02-14","XYZ000"),
(202,"Jason","","JONES","M","1972-11-10","+675 70034522",100,"Operational",'CK',100,"2021-04-03","2022-06-01","XYZ000"),
(203,"Mark","","LUCAS","M","1990-10-18","+675 75662211",100,"Operational",'CK',100,"2022-06-12","2023-05-04","XYZ000"),
(204,"Timothy","","MASON","M","1992-09-12","+675 79885643",100,"Operational",'SR',100,"2022-01-13","2022-06-12","XYZ000"),
(205,"Jimmy","Grant","THOMPSON","M","1984-01-13","+675 70998706",100,"Inventory","SR",100,"2022-03-16","2022-06-23","XYZ000"),
(206,"Jacinta","","MIKE","F","1989-04-10","+675 74432114",100,"Inventory",'TE',100,"2022-06-15","2023-03-15","XYZ000"),
(207,"Monica","Grace","ROBINSON","F","1979-09-08","+675 79950034",100,"Inventory",'TE',100,"2022-03-18","2022-06-15","XYZ000"),
(208,"Richard","","STANLEY","M","1995-03-23","+675 70083221",100,"Operational",'CR',100,"2022-03-23","2022-07-21","XYZ000"),
(209,"Daniel","","JERRY","M","1998-01-15","+675 70702334",100,"Operational",'CR',100,"2022-02-04","2023-05-23","XYZ000");

update manager set hoursWorked = 40 where EmployeeID = 200;
update manager set hoursWorked = 40 where EmployeeID = 201;
update clerk set clerkType="STORE", hoursWorked = 40 where EmployeeID = 202;
update clerk set clerkType="INV", hoursWorked = 40 where EmployeeID = 203;
update supervisor set hoursWorked = 40 where EmployeeID = 204;
update supervisor set hoursWorked = 40 where EmployeeID = 205;
update trainee set hoursWorked = 40 where EmployeeID = 206;
update trainee set hoursWorked = 40 where EmployeeID = 207;
update cashier set hoursWorked = 40 where EmployeeID = 208;
update cashier set hoursWorked = 40 where EmployeeID = 209;


-- customer IL - individual - CR corporate
insert into coporate_customer_address(addressID,streetName,zipCode) values
	(3100,"Default",211),
	(3101,"Goilanai",211),
	(3102,"Memorial",211),
	(3103,"Bottom Goilanai",211),
	(3104,"Bottom Town",211);

insert into customer(CUS_CustomerID,CUS_CustomerType) values
(13100,"IL"),
(13101,"CE"),
(13102,"CE"),
(13103,"CE"),
(13104,"CE"),
(13105,"CE"),
(13106,"IL"),
(13107,"IL"),
(13108,"IL"),
(13109,"IL");

-- update individual customer details
update individual set CUS_FirstName = "Johnathan",
	CUS_MiddleName = "Tim",
	CUS_LastName = "Benjamin",
	CUS_BirthDate = "1980-08-20",
	CUS_PhoneNumber = "+675 78822431",
	rewardsProgram_membership_status = 0 where CUS_CustomerID = 13100;

update individual set CUS_FirstName = "Nelson",
	CUS_MiddleName = "",
	CUS_LastName = "Sebastian",
	CUS_BirthDate = "1981-09-12",
	CUS_PhoneNumber = "+675 72224113",
	rewardsProgram_membership_status = 0 where CUS_CustomerID = 13106;

update individual set CUS_FirstName = "Grace",
	CUS_MiddleName = "",
	CUS_LastName = "Gibson",
	CUS_BirthDate = "1997-10-12",
	CUS_PhoneNumber = "+675 72231144",
	rewardsProgram_membership_status = 0 where CUS_CustomerID = 13107;

update individual set CUS_FirstName = "Sharon",
	CUS_MiddleName = "",
	CUS_LastName = "Thomas",
	CUS_BirthDate = "2001-02-21",
	CUS_PhoneNumber = "+675 79924418",
	rewardsProgram_membership_status = 0 where CUS_CustomerID = 13108;

update individual set CUS_FirstName = "Martin",
	CUS_MiddleName = "",
	CUS_LastName = "Gerald",
	CUS_BirthDate = "1982-09-13",
	CUS_PhoneNumber = "+675 70099832",
	rewardsProgram_membership_status = 0 where CUS_CustomerID = 13109;

-- update corporate customer details
update corporate set OrganizationName = "Hiwe Hiwe Lodge",
	authorisedNames = "HiweHiwe",
	addressID = 3100,
	contactNumber1 = "+675 72231444",
	contactNumber2 = "+675 73214451",
	paymentTerms = "PL",
	specialDiscounts = 0 where CUS_CustomerID = 13101;

update corporate set OrganizationName = "Bay Hotel",
	authorisedNames = "BayHotel",
	addressID = 3102,
	contactNumber1 = "+675 73321445",
	contactNumber2 = "+675 73341556",
	paymentTerms = "PL",
	specialDiscounts = 10 where CUS_CustomerID = 13102;

update corporate set OrganizationName = "Eliata Holdings",
	authorisedNames = "Eliata",
	addressID = 3103,
	contactNumber1 = "+675 73321145",
	contactNumber2 = "+325 19752",
	paymentTerms = "PL",
	specialDiscounts = 12 where CUS_CustomerID = 13103;

update corporate set OrganizationName = "Alotau Bakery",
	authorisedNames = "AlotauBakery",
	addressID = 3103,
	contactNumber1 = "+675 78332114",
	contactNumber2 = "+675 72231445",
	paymentTerms = "PL",
	specialDiscounts = 0 where CUS_CustomerID = 13104;

update corporate set OrganizationName = "Papindo Trading",
	authorisedNames = "Papindo",
	addressID = 3104,
	contactNumber1 = "+675 78322142",
	contactNumber2 = "+675 73319902",
	paymentTerms = "PN",
	specialDiscounts = 0 where CUS_CustomerID = 13105;


-- transaction
insert into tran_saction(TRAN_WhoPurchased,TRAN_DateTime,TRAN_WhoServedCustomer) values
	(13100,now(),201);

insert into items_purchased(ReceiptNumber,ItemID,Quantity) values
	(1,1000,5),
	(1,1001,4),
	(1,1004,5);

-- invoice

insert into purchaseorders(CustomerID,OrderDate) values
	(13101,curdate());

insert into invoice(OrderID,InvoicedBy) values
	(1,203);

insert into orderitems(orderID,itemID,Quantity) values
	(1,1000,30),
	(1,1001,20),
	(1,1002,30),
	(1,1003,50);
